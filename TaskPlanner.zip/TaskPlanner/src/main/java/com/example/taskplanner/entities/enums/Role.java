package com.example.taskplanner.entities.enums;

public enum Role {
    user,admin
}
