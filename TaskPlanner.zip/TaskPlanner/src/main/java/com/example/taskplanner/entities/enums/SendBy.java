package com.example.taskplanner.entities.enums;

public enum SendBy {
    EMAIL,SMS, BOTH
}
