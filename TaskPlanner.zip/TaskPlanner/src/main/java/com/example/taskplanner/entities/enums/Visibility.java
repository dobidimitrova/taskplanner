package com.example.taskplanner.entities.enums;

public enum Visibility {
    Public, Private
}
