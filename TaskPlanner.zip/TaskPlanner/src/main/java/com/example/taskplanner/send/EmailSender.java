package com.example.taskplanner.send;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailSender {
    private static final String FROM = "dobidimitrova12@abv.bg"; // Sender's email address
    private static final String HOST = "milev-test.eu"; // SMTP server address
    private static final String USERNAME = "milev@milev-test.eu"; // SMTP username (email address)
    private static final String PASSWORD = "milevchaleto981"; // SMTP password

    public static void sendEmail(String to, String subject, String body) {
        // Set up properties for the SMTP server
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", HOST);
        properties.setProperty("mail.smtp.port", "587"); // Port for TLS/STARTTLS
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true"); // Enable TLS

        // Create a session with an authenticator
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        });

        try {
            // Create a default MimeMessage object
            MimeMessage message = new MimeMessage(session);

            // Set From: header field
            message.setFrom(new InternetAddress(FROM));

            // Set To: header field
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            // Set Subject: header field
            message.setSubject(subject);

            // Set the actual message
            message.setText(body);

            // Send message
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Test sending an email
        sendEmail("recipient@example.com", "Test Subject", "Test body of the email");
    }
}
