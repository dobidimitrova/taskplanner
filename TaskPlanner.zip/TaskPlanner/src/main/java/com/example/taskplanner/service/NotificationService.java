package com.example.taskplanner.service;

public interface NotificationService {
}
