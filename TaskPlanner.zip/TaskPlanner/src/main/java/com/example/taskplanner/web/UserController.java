package com.example.taskplanner.web;

import com.example.taskplanner.dto.*;
import com.example.taskplanner.entities.Schedule;
import com.example.taskplanner.entities.Task;
import com.example.taskplanner.entities.User;
import com.example.taskplanner.repository.UserRepository;
import com.example.taskplanner.service.ScheduleService;
import com.example.taskplanner.service.TaskService;
import com.example.taskplanner.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService userService;
    private final ModelMapper modelMapper;
    private final ScheduleService scheduleService;
    private final TaskService taskService;
    private final UserRepository userRepository;

    @Autowired
    public UserController(UserService userService, ModelMapper modelMapper, ScheduleService scheduleService, ScheduleService scheduleService1, TaskService taskService, UserRepository userRepository) {
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.scheduleService = scheduleService1;
        this.taskService = taskService;
        this.userRepository = userRepository;
    }

    @GetMapping("/{id}/details")
    public String getUserDetails(@PathVariable("id") Long userId, Model model) {
        List<Schedule> schedulesCreatedByUser = scheduleService.getAllSchedulesCreatedByUser(userId);
        List<Task> tasksCreatedByUser = taskService.getAllTasksCreatedByUser(userId);
        List<User> subscribedUsers = userService.getUsersSubscribedByUserId(userId); // Add this line to get subscribed users
        User user = userService.findById(userId);

        model.addAttribute("schedulesCreatedByUser", schedulesCreatedByUser);
        model.addAttribute("tasksCreatedByUser", tasksCreatedByUser);
        model.addAttribute("subscribedUsers", subscribedUsers); // Add this line to pass the subscribed users to the view
        model.addAttribute("user", user);

        return "user-details";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        if (!model.containsAttribute("userRegisterModel")) {
            model.addAttribute("userRegisterModel", new UserRegisterModel());
        }
        return "register-page";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("userRegisterModel") @Valid UserRegisterModel userRegisterModel,
                               BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors() || !userRegisterModel.getPassword().equals(userRegisterModel.getConfirmPassword())) {
            if (!userRegisterModel.getPassword().equals(userRegisterModel.getConfirmPassword())) {
                model.addAttribute("passwordError", "Passwords do not match");
            }
            model.addAttribute("userRegisterModel", userRegisterModel);
            model.addAttribute("org.springframework.validation.BindingResult.userRegisterModel", bindingResult);
            return "register-page";
        }


        if (userService.usernameExists(userRegisterModel.getUsername())) {
            model.addAttribute("usernameError", "Username is already taken. Please choose another one.");
            model.addAttribute("userRegisterModel", userRegisterModel);
            return "register-page";
        }


        if (userService.emailExists(userRegisterModel.getEmail())) {
            model.addAttribute("emailError", "Email is already registered. Please use another one.");
            model.addAttribute("userRegisterModel", userRegisterModel);
            return "register-page";
        }


        userService.registerModel(userRegisterModel);
        return "login-page";
    }

    @GetMapping("/login")
    public String loginPage(Model model){
        if(!model.containsAttribute("userLoginModel")){
            model.addAttribute("userLoginModel", new UserLoginModel());
        }
        return "login-page";
    }

    @PostMapping("/login")
    public String loginConfirm(@ModelAttribute("userLoginModel") @Valid UserLoginModel userLoginModel,
                               BindingResult bindingResult,
                               RedirectAttributes redirectAttributes,
                               HttpSession httpSession) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("userLoginModel", userLoginModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userLoginModel", bindingResult);
            return "redirect:/user/login";
        }

        UserLoginServiceModel userServiceModel = userService.findByUsernameAndPassword(userLoginModel.getUsername(), userLoginModel.getPassword());

        if (userServiceModel == null) {
            redirectAttributes.addFlashAttribute("userLoginModel", userLoginModel);
            redirectAttributes.addFlashAttribute("loginError", "Invalid username or password."); // Pass error message to the frontend
            return "redirect:/user/login";
        }

        httpSession.setAttribute("user", userServiceModel.getUsername());
        httpSession.setAttribute("userId", userServiceModel.getId());
        httpSession.setAttribute("role", userServiceModel.getRole());
        return "redirect:/user/calendar-page";
    }



    @GetMapping("/calendar-page")
    public String calendarPage(Model model, HttpSession httpSession) {
        if (httpSession.getAttribute("user") == null) {
            return "redirect:/"; // Пренасочване към страницата за логин
        }
        return "calendar-page";
    }

    @GetMapping("/all-users")
    public String getAllUsers(HttpSession httpSession, Model model) {
        if (httpSession.getAttribute("user") == null) {
            return "redirect:/"; // Пренасочване към страницата за логин
        }
        String role = (String) httpSession.getAttribute("role");
        if (!"admin".equals(role)) {
            return "redirect:/"; 
        }
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        return "all-users";
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "index-page";
    }
}
