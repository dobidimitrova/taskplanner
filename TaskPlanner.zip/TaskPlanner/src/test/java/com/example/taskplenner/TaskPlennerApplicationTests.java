package com.example.taskplenner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskPlennerApplicationTests {

    @Test
    void contextLoads() {
    }

}
